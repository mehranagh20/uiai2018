import math
import random

from client import *
import numpy as np


def init_players():
    '''
    Here you can set each of your player's name and your team formation.
    In case of setting wrong position, server will set default formation for your team.
    '''

    players = [Player(name="0", first_pos=Pos(-6.5, 1)),
               Player(name="1", first_pos=Pos(-6.5, 0)),
               Player(name="2", first_pos=Pos(-6.5, -1)),
               Player(name="3", first_pos=Pos(-5, 0)),
               Player(name="4", first_pos=Pos(-2, 0))]
    return players


def dist_two_point(x1, y1, x2, y2):
    return math.sqrt((x1 - x2) ** 2 + (y1 - y2) ** 2)

#
# def conflict(x1, y1, ang, players):
#     m = math.tan(math.radians(ang))
#     x2 = 10
#     y2 = m * (x2 - x1) + y1
#     p1 = np.array([x2, y2])
#     p2 = np.array([x1, y1])
#     closest_obj = -1
#     closest_dist = 1000
#     for pid in players:
#         b1 = pid.getPosition().getX()
#         b2 = pid.getPosition().getY()
#         p3 = np.array([b1, b2])
#         d = abs(np.cross(p2 - p1, p3 - p1) / np.linalg.norm(p2 - p1))
#         if d < .75 and isinstance(pid, Ball) and dist_two_point(x1, y1, b1, b2) < closest_dist:
#             # print("ball in ", pid.getPosition().getX(), " ", pid.getPosition().getY(), "is conflicted:")
#             # print("d is: ", d)
#             # print("type of ball : ", type(pid))
#             closest_dist = dist_two_point(x1, y1, b1, b2)
#             closest_obj = pid
#         elif d < 1 and dist_two_point(x1, y1, b1, b2) < closest_dist:
#             # print("player in ", pid.getPosition().getX(), " ", pid.getPosition().getY(), "is conflicted:")
#             # print("d is: ", d)
#             closest_dist = dist_two_point(x1, y1, b1, b2)
#             closest_obj = pid
#     return closest_obj


def do_turn(game):
    act = Triple()
    opp_gate_pos = [(7, 1.4), (7, -1.4)]
    player_id = random.randint(0, 4)
    opp_players = []
    opp_and_baal = []
    my_players = []
    angle = 0
    # for pid in range(0, 5):
    #     opp_players.append(game.getOppTeam().getPlayer(pid))
    #     opp_and_baal.append(game.getOppTeam().getPlayer(pid))
    #     my_players.append(game.getMyTeam().getPlayer(pid))
    # opp_and_baal.append(game.getBall())
    #
    # # con = conflict(-5, 2, -18.42, opp_and_baal)
    # # print("---------------------------------")
    # # print(" in ", con.getPosition().getX(), " ", con.getPosition().getY(), "is conflicted:")
    # # print("type of object : ", type(con))
    #
    # for pid in my_players:
    #     x1 = pid.getPosition().getX()
    #     y1 = pid.getPosition().getY()
    #     print("player is at :", x1, " ", y1)
    #     if x1 > game.getBall().getPosition().getX():
    #         continue
    #     for deg in range(-85, 85):
    #         con = conflict(x1, y1, deg, opp_and_baal)
    #         if con != -1 and isinstance(con, Ball):
    #             print("ball: ", game.getBall().getPosition().getX(), " ", game.getBall().getPosition().getY())
    #             print("first conflicted:", con.getPosition().getX(), " ", con.getPosition().getY())
    #             print("degree", deg)
    #             angle = deg
    #             player_id = pid.getId()
    #             print("player id : ", player_id)
    #             break

    final_angle = 0
    found = -1
    for pid in range(0, 5):
        x1 = game.getMyTeam().getPlayer(pid).getPosition().getX()
        y1 = game.getMyTeam().getPlayer(pid).getPosition().getY()
        if x1 > game.getBall().getPosition().getX():
            continue
        temp = (math.degrees(math.atan2(opp_gate_pos[0][1] - y1, opp_gate_pos[0][0] - x1)), math.degrees(math.atan2(opp_gate_pos[1][1] - y1, opp_gate_pos[1][0] - x1)))
        gate_angle = (min(temp[0], temp[1]), max(temp[0], temp[1]))
        x2 = game.getBall().getPosition().getX()
        y2 = game.getBall().getPosition().getY()
        angle = math.degrees(math.atan2(y2 - y1, x2 - x1))
        if gate_angle[0] < angle < gate_angle[1]:
            if found == -1:
                player_id = pid
                final_angle = angle
            elif game.getMyTeam().getPlayer(player_id).getPosition().getX() < x1:
                player_id = pid
                final_angle = angle
            found = 1
    if found == -1:
        final_angle = 180
        for pid in range(0, 5):
            x1 = game.getMyTeam().getPlayer(pid).getPosition().getX()
            y1 = game.getMyTeam().getPlayer(pid).getPosition().getY()
            x2 = game.getBall().getPosition().getX()
            y2 = game.getBall().getPosition().getY()
            angle = math.degrees(math.atan2(y2 - y1, x2 - x1))
            if abs(angle) < abs(final_angle):
                angle = final_angle

    act.setPlayerID(player_id)
    if final_angle < 0:
        final_angle += 360
    act.setAngle(final_angle)

    act.setPower(100)

    return act
